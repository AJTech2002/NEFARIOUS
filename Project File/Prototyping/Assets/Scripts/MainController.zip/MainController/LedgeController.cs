﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LedgeController : Controller {

    //PRIVATE VARS
    private Vector3 hitPosition;
    private Vector3 myDir;

    

    private void Awake()
    {
       
    }

    public override void ExternalFixedUpdate()
    {
        m.rBody.isKinematic = true;

        //
        Vector3 lookPoint = hitPosition - myDir;
        lookPoint.y = m.transform.position.y;
        m.transform.LookAt(lookPoint);
        m.transform.position = Vector3.Lerp(m.transform.position, hitPosition + (myDir * 0.5f), 0.3f);
        //

    }

    public void ResetPosition (Vector3 hitPosition, Vector3 myDir)
    {

        this.hitPosition = hitPosition;
        this.myDir = myDir;

    }
    
}
